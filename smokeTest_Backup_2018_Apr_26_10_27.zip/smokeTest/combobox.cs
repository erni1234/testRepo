﻿/*
 * Created by Ranorex
 * User: erdogb
 * Date: 20.04.2018
 * Time: 16:22
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace smokeTest
{
    /// <summary>
    /// Description of combobox.
    /// </summary>
    [TestModule("A87A9D00-3562-4918-8722-9DB38A25A349", ModuleType.UserCode, 1)]
    public class combobox : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public combobox()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
            
            ComboBox iOModuleType = "/form[@title~'^elproMONITOR\\ -\\ I/O\\ Module' and @processname='firefox']/container[@accessiblerole='Grouping']/container[13]/?/?/container[@accessiblename~'^elproMONITOR\\ -\\ I/O\\ Module']/element[2]/element[3]/element[2]/element[@accessiblerole='None']/element[@accessiblerole='None']/element[@accessiblerole='None']/element[2]/list[1]/listitem[@accessiblename='I/O Module Type n/a']/combobox[@accessiblename='I/O Module Type']";
            iOModuleType.Click();
            iOModuleType.SelectedItemIndex = 1;
            
            
          
        }
    }
}
