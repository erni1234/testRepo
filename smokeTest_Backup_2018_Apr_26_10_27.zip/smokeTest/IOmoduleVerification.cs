﻿/*
 * Created by Ranorex
 * User: erdogb
 * Date: 11.04.2018
 * Time: 13:20
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.Drawing;
using System.Threading;
using WinForms = System.Windows.Forms;

using Ranorex;
using Ranorex.Core;
using Ranorex.Core.Testing;

namespace smokeTest
{
    /// <summary>
    /// Description of IOmoduleVerification.
    /// </summary>
    [TestModule("E2ED32A3-3DF2-4157-929D-9A94A76D89B8", ModuleType.UserCode, 1)]
    public class IOmoduleVerification : ITestModule
    {
        /// <summary>
        /// Constructs a new instance.
        /// </summary>
        public IOmoduleVerification()
        {
            // Do not delete - a parameterless constructor is required!
        }

        /// <summary>
        /// Performs the playback of actions in this module.
        /// </summary>
        /// <remarks>You should not call this method directly, instead pass the module
        /// instance to the <see cref="TestModuleRunner.Run(ITestModule)"/> method
        /// that will in turn invoke this method.</remarks>
        void ITestModule.Run()
        {
            Mouse.DefaultMoveTime = 300;
            Keyboard.DefaultKeyPressTime = 100;
            Delay.SpeedFactor = 1.0;
            
            
            var repo = smokeTestRepository.Instance;
      
            var navDeviceSettingsIoModules = repo.ElproMONITORLogin.NavDeviceSettingsIoModules;
            var checkbox = repo.ElproMONITORLogin.ListDataTableNoFooter.Checkbox;
            var navDeviceSettingsIndex = repo.ElproMONITORLogin.NavDeviceSettingsIndex;
            var elproMONITORIOModules = repo.ElproMONITORIOModules;
        
            
            navDeviceSettingsIndex.Click();
            navDeviceSettingsIoModules.Click();
            
            Delay.Milliseconds(500);
             
            H1Tag h1TagIOModules = "/dom[1]//div[#'contentCenter']/?/?/h1[@innertext~'^\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ I/O\\ Modules']"; 
          
              
           navDeviceSettingsIoModules.Click();
            
           Validate.Exists("/dom[1]//div[#'contentCenter']/?/?/h1[@innertext~'^\\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ \\ I/O\\ Modules']");
             
          
          TdTag tdTagLB = "/dom[@caption~'^elproMONITOR\\ -\\ I/O\\ Module']//table[#'DataTables_Table_0']/tbody/tr[1]/td[3]";
          tdTagLB.Click();

          ButtonTag report = "/dom[1]//div[#'contentRight']/?/?/button[@innertext='Report']";    
          ButtonTag edit = "/dom[1]//div[#'contentRight']/?/?/button[@innertext='Edit']";  
          ButtonTag close = "/dom[1]//div[#'contentRight']/?/?/button[@innertext='Close']"; 
          ButtonTag delete = "/dom[1]//div[#'contentRight']/?/?/button[@innertext='Delete']";            
           
        
           
         
            Validate.Exists(repo.ElproMONITORIOModules.ContentRight.ReportInfo);                        
            Report.Screenshot(report);
            Report.Info(repo.ElproMONITORIOModules.ContentRight.Report.Enabled.ToString());
            
            Validate.Exists(repo.ElproMONITORIOModules.ContentRight.DeleteInfo);
            Report.Screenshot(delete);
            
            Validate.Exists(repo.ElproMONITORIOModules.ContentRight.CloseInfo);
            Report.Screenshot(close);
                        
           
            
            Validate.Exists(repo.ElproMONITORIOModules.ContentRight.EditInfo);
            Report.Screenshot(edit);
            
            
            Validate.Exists(repo.ElproMONITORIOModules.ContentRight.AddNewIOModuleInfo);
            Report.Screenshot(repo.ElproMONITORIOModules.ContentRight.AddNewIOModule);
            
           
        }
    }
}
